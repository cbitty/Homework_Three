using UnityEngine;

public class FloatingObstacleScript : MonoBehaviour
{
    private Renderer renderer;
    private Rigidbody rb;

    void Start()
    {
        renderer = GetComponent<Renderer>();
        rb = GetComponent<Rigidbody>();
        renderer.enabled = false; // Make it invisible
        rb.useGravity = false;    // Prevent it from falling initially
        Invoke("ActivateObstacle", 5f); // Call ActivateObstacle after 5 seconds
    }

    void ActivateObstacle()
    {
        renderer.enabled = true; // Make it visible
        rb.useGravity = true;    // Allow it to fall
    }
}
